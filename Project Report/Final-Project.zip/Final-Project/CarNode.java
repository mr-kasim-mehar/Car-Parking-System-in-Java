public class CarNode {
    Details car;
    CarNode next;

    public CarNode(Details car) {
        this.car = car;
        this.next = null;
    }
}
